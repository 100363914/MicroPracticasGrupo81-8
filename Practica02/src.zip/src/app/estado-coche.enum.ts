export enum EstadoCoche {
    BUENO = 'BUENO',
    MALO = 'MALO'
}