import { Pipe, PipeTransform } from '@angular/core';
import { Coche } from './coche';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(coches: Coche[], search:string): Coche[] {
    return coches.filter((coche:Coche) => {
      let listOfWords = coche.getWords();
      let filterWords = search.split(' ');

      for(let key of filterWords){
        for(let exampleWord of listOfWords){
          if(exampleWord.indexOf(key) == 0){
            return true;
          }
        }
      }
      return false;
    });

    
  }

}
